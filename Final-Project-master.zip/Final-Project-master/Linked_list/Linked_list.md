# Linked List

Ready of the [next challenge](../Tree/Tree.md)? or [Return to overview](../README.md)
